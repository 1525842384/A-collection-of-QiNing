#include "roomclassmanagement.h"
#include "ui_roomclassmanagement.h"

roomClassManagement::roomClassManagement(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::roomClassManagement)
{
    ui->setupUi(this);
}

roomClassManagement::~roomClassManagement()
{
    delete ui;
}

void roomClassManagement::on_pushButton_clicked()
{
    this->accept();
}
