#include "login.h"
#include "ui_login.h"
#include <QDebug>
#include <QMessageBox>
logIn::logIn(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::logIn)
{
    ui->setupUi(this);
}

logIn::~logIn()
{
    delete ui;
}

void logIn::on_pushButton_clicked()
{
    qDebug()<<"log in";
    QString strUser = ui->lineEdit->text();

    if(strUser == "123")
    {
        QMessageBox::information(this,"remind","success!",QMessageBox::Ok);
        this->close();
//        MainWindow dlg;
//        dlg.show();
//        if(ret == QDialog::Accepted)
//        {
//            this->show();
//        }
    }
    else
    {
        QMessageBox::warning(this,"warning","failed",QMessageBox::Ok);
    }
}
