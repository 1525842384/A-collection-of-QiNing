#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "roomclassmanagement.h"
#include "ui_roomclassmanagement.h"
#include <QIcon>
#include <QAction>
#include <QDebug>
#include <QPalette>
#include <QPixmap>
#include <QBrush>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //设置背景
    QPalette pal;
    pal.setBrush(this->backgroundRole(),QBrush(QPixmap
                        (":/images/C:/Users/94843/Desktop/PhotoResource/tool_6.jpg")));
    this->setPalette(pal);


    //添加菜单目录1
    QIcon icon_1(":/images/C:/Users/94843/Desktop/PhotoResource/test4.jpg");
    QAction* act1_1 = new QAction(icon_1,"影厅类型管理",this);
    ui->menu->addAction(act1_1);
    //目录1建立连接
    connect(act1_1,SIGNAL(triggered()),this,SLOT(showMenu1_1()));

    //添加菜单目录2
    QIcon icon_2(":/images/C:/Users/94843/Desktop/PhotoResource/test4.jpg");
    QAction* act2_1 = new QAction(icon_2,"用户管理",this);
    ui->menu_2->addAction(act2_1);
    //目录2建立连接
    connect(act2_1,SIGNAL(triggered()),this,SLOT(showMenu2_1()));

    //添加菜单目录3
    QIcon icon_3(":/images/C:/Users/94843/Desktop/PhotoResource/test4.jpg");
    QAction* act3_1 = new QAction(icon_3,"影厅信息管理",this);
    ui->menu_3->addAction(act3_1);
    //目录3建立连接
    connect(act3_1,SIGNAL(triggered()),this,SLOT(showMenu3_1()));

    //添加菜单目录4
    QIcon icon_4(":/images/C:/Users/94843/Desktop/PhotoResource/test4.jpg");
    QAction* act4_1 = new QAction(icon_4,"消费入账",this);
    ui->menu_4->addAction(act4_1);
    //目录4建立连接
    connect(act4_1,SIGNAL(triggered()),this,SLOT(showMenu4_1()));

    //添加菜单目录5
    QIcon icon_5(":/images/C:/Users/94843/Desktop/PhotoResource/test4.jpg");
    QAction* act5_1 = new QAction(icon_5,"票房分析",this);
    ui->menu_5->addAction(act5_1);
    //目录5建立连接
    connect(act5_1,SIGNAL(triggered()),this,SLOT(showMenu5_1()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::showMenu1_1()
{
    this->hide();
    roomClassManagement dlgOne;
    int ret =dlgOne.exec();
    if(ret == QDialog::Accepted)
    {
        this->show();
    }
//    QString strUser = ui->lineEdit->text();

//    if(strUser == "213173086")
//    {
//        QMessageBox::information(this,"remind","success!",QMessageBox::Ok);
//        this->hide();
//        AnotherWidgit dlg;
//        int ret = dlg.exec();
//        if(ret == QDialog::Accepted)
//        {
//            this->show();
//        }
//    }
//    else
//    {
//        QMessageBox::warning(this,"warning","failed",QMessageBox::Ok);
//    }
    qDebug()<<"showMenu1_1";
}

//显示菜单1，2,3,4,5
void MainWindow::showMenu2_1()
{
    qDebug()<<"showMenu2_1";
}

void MainWindow::showMenu3_1()
{
    qDebug()<<"showMenu3_1";
}

void MainWindow::showMenu4_1()
{
    qDebug()<<"showMenu4_1";
}

void MainWindow::showMenu5_1()
{
    qDebug()<<"showMenu5_1";
}
