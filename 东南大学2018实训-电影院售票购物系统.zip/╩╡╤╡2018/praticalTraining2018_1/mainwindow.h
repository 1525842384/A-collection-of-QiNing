#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

public slots:
    void showMenu1_1();
    void showMenu2_1();
    void showMenu3_1();
    void showMenu4_1();
    void showMenu5_1();
private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
