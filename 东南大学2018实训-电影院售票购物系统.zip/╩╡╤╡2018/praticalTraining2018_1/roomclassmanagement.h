#ifndef ROOMCLASSMANAGEMENT_H
#define ROOMCLASSMANAGEMENT_H

#include <QDialog>

namespace Ui {
class roomClassManagement;
}

class roomClassManagement : public QDialog
{
    Q_OBJECT

public:
    explicit roomClassManagement(QWidget *parent = 0);
    ~roomClassManagement();

private slots:
    void on_pushButton_clicked();

private:
    Ui::roomClassManagement *ui;
};

#endif // ROOMCLASSMANAGEMENT_H
