# encoding=utf-8
import shutil
import pymysql
import os
import re
import spamdetect

#account1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234','email',charset='utf8')
#cursor = account1.cursor()

#emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234','emailaccount',charset='utf8')
#cursor2 = emailaccount.cursor()

#emailsender = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234','emailsender',charset='utf8')
#cursor3 = emailsender.cursor()

#contact1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234','contact',charset='utf8')
#cursor4 = contact1.cursor()

#spamEmail1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234','spamemail',charset='utf8')
#cursor5 = spamEmail1.cursor()
MailType = ['detecting','spam','ham','pending']
ContactType = ['normal','white','black']
ReadState = ['0', '1']

def changeNameType(EmailName):
    namelist = re.split("@|\.",EmailName)
    sqlName = namelist[0] + "_" + namelist[1] + "_" + namelist[2]
    return sqlName

def returnNameType(sqlName):
    namelist = sqlName.split('_')
    Emailname = namelist[0] + '@' + namelist[1] + '.' + namelist[2]
    return Emailname

def newTable():
    account1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234',
                               'email', charset='utf8')
    cursor = account1.cursor()
    cursor.execute("DROP TABLE IF EXISTS ACCOUNT")
    sql = """CREATE TABLE ACCOUNT (
            EmailName CHAR(20) NOT NULL,
            Password CHAR(16) NOT NULL,
            ContactNum INT(5),
            ReceiveEmailNum INT(5),
            SendEmailNum INT(5))CHARSET=utf8
            """
    cursor.execute(sql)
    cursor.close()
    account1.close()

def insertAccount(name, password):
    sql = "INSERT INTO ACCOUNT VALUES('%s', '%s',0,0,0)"%(name, password)
    account1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234',
                               'email', charset='utf8')
    cursor = account1.cursor()
    try:
        # 执行sql语句
        cursor.execute(sql)
        # 执行sql语句
        account1.commit()
        cursor.close()
        account1.close()
    except:
        # 发生错误时回滚
        account1.rollback()
def insertEmailAccount(name):
    try:
        emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                       'Shixun1234', 'emailaccount', charset='utf8')
        cursor2 = emailaccount.cursor()
        cursor2.execute("CREATE TABLE %s (Title CHAR(25), Date CHAR(20), Text TEXT, Sender CHAR(20), MailType CHAR(20), ReadState CHAR(10))CHARSET=utf8"%name)
        emailaccount.commit()
        cursor2.close()
        emailaccount.close()
    except:
        emailaccount.rollback()
def insertEmailSender(name):
    try:
        emailsender = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                      'Shixun1234', 'emailsender', charset='utf8')
        cursor3 = emailsender.cursor()
        cursor3.execute("CREATE TABLE %s (Title CHAR(25), Date CHAR(20), Text TEXT, Receiver CHAR(20))CHARSET=utf8"%name)
        emailsender.commit()
        cursor3.close()
        emailsender.close()
    except:
        emailsender.rollback()
def insertContactTable(name):
    try:
        contact1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'contact', charset='utf8')
        cursor4 = contact1.cursor()
        cursor4.execute("CREATE TABLE %s (EmailName CHAR(20), Nickname CHAR(20), Type CHAR(10))CHARSET=utf8"%name)
        contact1.commit()
        cursor4.close()
        contact1.close()
    except:
        contact1.rollback()
#def insertSpamEmailTable(name):
    #try:
        #cursor5.execute("CREATE TABLE %s (tit CHAR(25), date CHAR(20), text TEXT, sender CHAR(20))CHARSET=utf8"%name)
        #spamEmail1.commit()
    #except:
        #contact1.rollback()
#数据库注册，新建一个账号，并给此账户名建一个收件箱表
def register(name,password):
    if searchAccountName(name):
        print("用户已存在")
        return "defeat"
    else:
       sqlName = changeNameType(name)
       insertAccount(name,password)
       insertEmailAccount(sqlName)
       insertEmailSender(sqlName)
       insertContactTable(sqlName)
       #insertSpamEmailTable(name)
       result = "succeed"
       return result

#登录
def login(name,password):
    uName = searchAccountName(name)
    if uName:
        uPass = str(searchAccountPassword(name))
        if (uPass.strip() == password.strip()):
            result = "succeed"
            #detectSpam(name)
            return result
        else:
            result = "wrongPassword"
            return result
    else:
        print("账户不存在")
        result = 'noAccount'
        return result

#数据库查询账户的密码0
def searchAccountPassword(name):
    sql = "SELECT * FROM ACCOUNT WHERE EmailName = '%s'"%(name)
    account1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234',
                               'email', charset='utf8')
    cursor = account1.cursor()
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 获取所有记录列表
        results = cursor.fetchall()
        for row in results:
           #uname = row[0]
           upassword = row[1]
           # 打印结果
           #print("name=%s,password=%s" % (uname, upassword))
           return upassword
        cursor.close()
        account1.close()
    except:
        print("Error: unable to fetch data")

#数据库查询账户是否存在
def searchAccountName(Emailname):
    sql = "SELECT * FROM ACCOUNT WHERE EmailName = '%s'"%(Emailname)
    account1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234',
                               'email', charset='utf8')
    cursor = account1.cursor()
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 获取所有记录列表
        results = cursor.fetchall()
        for row in results:
           uname = row[0]
           #ucontactnum = row[2]
           #ureceivenum = row[3]
           #usendnum = row[4]
           # 打印结果
           #print("EmailName=%s,Password=%s" % (uname, upassword))
           return uname
        cursor.close()
        account1.close()
    except:
        print("Error: unable to fetch data")

#查询账户信息
def searchAccount(Emailname):
    sql = "SELECT * FROM ACCOUNT WHERE EmailName = '%s'"%(Emailname)
    account1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234',
                               'email', charset='utf8')
    cursor = account1.cursor()
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 获取所有记录列表
        results = cursor.fetchall()
        for row in results:
           uname = row[0]
           upassword = row[1]
           ucontactnum = row[2]
           ureceivenum = row[3]
           usendnum = row[4]
           # 打印结果
           #print("EmailName=%s,Password=%s" % (uname, upassword))
           return uname,upassword,ucontactnum,ureceivenum,usendnum
        cursor.close()
        account1.close()
    except:
        print("Error: unable to fetch data")

#删除账户表
def deleteAccount(name,password):
    sql = "DELETE FROM ACCOUNT WHERE EmailName = '%s' AND Password = '%s'" % (name, password)
    account1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234',
                               'email', charset='utf8')
    cursor = account1.cursor()
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 提交修改
        account1.commit()
        cursor.close()
        account1.close()
    except:
        # 发生错误时回滚
        account1.rollback()
#删除收件表
def deleteEmailAccountTable(name):
    try:
        emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                       'Shixun1234', 'emailaccount', charset='utf8')
        cursor2 = emailaccount.cursor()
        cursor2.execute("DROP TABLE IF EXISTS %s" % name)
        emailaccount.commit()
        cursor2.close()
        emailaccount.close()
    except:
        emailaccount.rollback()
#删除发件表
def deleteEmailSenderTable(name):
    try:
        emailsender = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                      'Shixun1234', 'emailsender', charset='utf8')
        cursor3 = emailsender.cursor()
        cursor3.execute("DROP TABLE IF EXISTS %s" % name)
        emailsender.commit()
        cursor3.close()
        emailsender.close()
    except:
        emailsender.rollback()
#删除联系人表
def deleteContactTable(name):
    try:
        contact1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'contact', charset='utf8')
        cursor4 = contact1.cursor()
        cursor4.execute("DROP TABLE IF EXISTS %s" % name)
        contact1.commit()
        cursor4.close()
        contact1.close()
    except:
        contact1.rollback()
#数据库删除一个账户及收件箱及已发送箱
def delete(name,password):
    upassword = str(searchAccountPassword(name))
    upass = str(password)
    #print(upassword)
    #print(upass)
    if upassword.strip() != upass.strip():
       print("密码错误")
    else:
       sqlName =changeNameType(name)
       deleteAccount(name,password)
       deleteEmailAccountTable(sqlName)
       deleteEmailSenderTable(sqlName)
       deleteContactTable(sqlName)

#数据库修改账户密码
def updateAccountPassword(name, oldpass, newpass):
    uName = searchAccountName(name)
    result = 'defeat'
    if uName:
       upassword = str(searchAccountPassword(name))
       uoldpass = str(oldpass)
       #print(upassword)
       #print(oldpass)
       if upassword.strip() != uoldpass.strip():
           print("密码错误")
           return result
       else:
          sql = "UPDATE ACCOUNT SET Password = '%s' WHERE EmailName = '%s' AND Password = '%s'" % \
                (newpass,name,oldpass)
          account1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                     'Shixun1234', 'email', charset='utf8')
          cursor = account1.cursor()
          try:
              # 执行SQL语句
              cursor.execute(sql)
              # 提交到数据库执行
              account1.commit()
              cursor.close()
              account1.close()
          except:
              # 发生错误时回滚
              account1.rollback()
          result = 'succeed'
          return result
    else:
        print("用户不存在")
        return result

#更新收到邮件数目
def updateReceiveEmailNum(sender,receiver,num):
    sName,sPass,sContact,sReceive,sSend = searchAccount(sender)
    rName,rPass,rContact,rReceive,rSend = searchAccount(receiver)
    if sName and rName:
        sql = "UPDATE ACCOUNT SET ReceiveEmailNum = %s WHERE EmailName = '%s'" % \
              (rReceive+num,rName)
        account1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'email', charset='utf8')
        cursor = account1.cursor()
        try:
            # 执行SQL语句
            cursor.execute(sql)
            # 提交到数据库执行
            account1.commit()
            cursor.close()
            account1.close()
        except:
            # 发生错误时回滚
            account1.rollback()
    else:
        print("数目错误")
#更新发送邮件数目
def updateSendEmailNum(sender,receiver,num):
    sName,sPass,sContact,sReceive,sSend = searchAccount(sender)
    rName,rPass,rContact,rReceive,rSend = searchAccount(receiver)
    if sName and rName:
        sql = "UPDATE ACCOUNT SET SendEmailNum = %s WHERE EmailName = '%s'" % \
              (sSend+num,sName)
        account1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'email', charset='utf8')
        cursor = account1.cursor()
        try:
            # 执行SQL语句
            cursor.execute(sql)
            # 提交到数据库执行
            account1.commit()
            cursor.close()
            account1.close()
        except:
            # 发生错误时回滚
            account1.rollback()
    else:
        print("数目错误")


#往下是邮箱的功能
#收件箱数据库收到一封新邮件
def newEmail(receiver,title,date,text,sender):
    if searchAccountName(receiver):
        sqlName1 = changeNameType(receiver)
        sqlName2 = changeNameType(sender)
        emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver','Shixun1234', 'emailaccount', charset='utf8')
        cursor2 = emailaccount.cursor()
        emailsender = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver','Shixun1234', 'emailsender', charset='utf8')
        cursor3 = emailsender.cursor()
        sql = "INSERT INTO %s VALUES('%s', '%s', '%s', '%s', '%s', '%s')" % (sqlName1, title, date, text, sqlName2, MailType[0], ReadState[0])
        try:
            cursor2.execute(sql)
            emailaccount.commit()
            cursor2.close()
            emailaccount.close()
        except:
            emailaccount.rollback()
        sql2 = "INSERT INTO %s VALUES('%s', '%s', '%s', '%s')" % (sqlName2, title, date, text, sqlName1)
        try:
            cursor3.execute(sql2)
            emailsender.commit()
            cursor3.close()
            emailsender.close()
        except:
            emailsender.rollback()
        type = searchContact(receiver,sender)
        senderType = str(type).strip()
        if(senderType == 'black'):
            changeToSpam(receiver,title)
        if(senderType == 'white'):
            changeToHam(receiver,title)
        updateSendEmailNum(sender,receiver,1)
        updateReceiveEmailNum(sender, receiver, 1)
        result = 'succeed'
    else:
        print("投递用户不存在")
        result = 'defeat'
    return result

#群发邮件
def newGroupEmail(receiverList,title,date,text,sender):
    num = len(receiverList)
    succeedNum = 0
    for i in range(num):
        result = newEmail(receiverList[i], title, date, text, sender)
        if (result.strip() == "succeed"):
            succeedNum = succeedNum + 1
        #print(result+ ":" + receiverList[i])
    allResult = str(succeedNum) + "发送成功；" + str(num-succeedNum) + "发送失败。"
    #print(allResult)
    return allResult

#导出邮件
def exportEmail(receiver):
    sqlName = changeNameType(receiver)
    emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'emailaccount', charset='utf8')
    cursor2 = emailaccount.cursor()
    sql = "SELECT * FROM %s WHERE MailType = 'detecting'" % (sqlName)
    path = 'data/' + sqlName
    isExists = os.path.exists(path)
    if not isExists:
        os.makedirs(path)
    if isExists:
        shutil.rmtree(path)
        os.makedirs(path)
        try:
            # 执行SQL语句
            cursor2.execute(sql)
            # 获取所有记录列表
            results = cursor2.fetchone()
            while results:
                print(results)
                title = str(results[0])
                print(title)
                Text = str(results[2])
                fh = open(path + "/" + title + '.txt', 'w')
                fh.write(Text)
                fh.close()
                results = cursor2.fetchone()
            cursor2.close()
            emailaccount.close()
        except:
            print("!Error: unable to fetch data")
    return sqlName

#返回邮件检测结果
def returnSpamDetectResult(filename,user):
    title = []
    result = []
    with open(filename, 'r') as file_to_read:
        while True:
            lines = str(file_to_read.readline())  # 整行读取数据
            print(lines)
            if not lines:
                break
            list = lines.split(',')
            p_tmp = list[0]
            titlename = p_tmp.split('.')
            E_tmp = list[1]  # 将整行数据分割处理，如果分割符是空格，括号里就不用传入参数，如果是逗号， 则传入‘，'字符。
            if(E_tmp.strip() == '0'):
                changeToHam(user,titlename[0])
            else:
                changeToPending(user,titlename[0])
            title.append(p_tmp)  # 添加新读取的数据
            result.append(E_tmp)
    return

#垃圾邮件测试
def detectSpam(user):
    filename = exportEmail(user)
    spamdetect.SpamEmailDetect(filename)
    returnSpamDetectResult('result.txt',user)

#设置为待处理邮件
def changeToPending(user,title):
    sqlName = changeNameType(user)
    sql = "UPDATE %s SET MailType = '%s' WHERE Title = '%s'" % (sqlName, MailType[3], title)
    emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'emailaccount', charset='utf8')
    cursor2 = emailaccount.cursor()
    try:
        cursor2.execute(sql)
        emailaccount.commit()
        cursor2.close()
        emailaccount.close()
        return 'removeSucceed'
    except:
        emailaccount.rollback()
        return 'removeDefeat'

#设置为非垃圾邮件
def changeToSpam1(user,sender,title,date):
    sqlName = changeNameType(user)
    sqlName2 = changeNameType(sender)
    sql = "UPDATE %s SET MailType = '%s' WHERE Title = '%s' AND Sender = '%s' AND Date = '%s'" % (sqlName, MailType[1], title, sqlName2, date)
    print(sql)
    emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'emailaccount', charset='utf8')
    cursor2 = emailaccount.cursor()
    try:
        cursor2.execute(sql)
        emailaccount.commit()
        cursor2.close()
        emailaccount.close()
        return 'removeSucceed'
    except:
        emailaccount.rollback()
        return 'removeDefeat'
def changeToSpam(user,title):
    sqlName = changeNameType(user)
    sql = "UPDATE %s SET MailType = '%s' WHERE Title = '%s'" % (
    sqlName,MailType[1],title)
    print(sql)
    emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'emailaccount', charset='utf8')
    cursor2 = emailaccount.cursor()
    try:
        cursor2.execute(sql)
        emailaccount.commit()
        cursor2.close()
        emailaccount.close()
        return 'removeSucceed'
    except:
        emailaccount.rollback()
        return 'removeDefeat'
#设置为垃圾邮件
def changeToHam1(user,sender,title,date):
    sqlName = changeNameType(user)
    sqlName2 = changeNameType(sender)
    sql = "UPDATE %s SET MailType = '%s' WHERE Title = '%s' and Sender = '%s' and Date = '%s'" % (sqlName, MailType[2], title, sqlName2, date)
    emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'emailaccount', charset='utf8')
    cursor2 = emailaccount.cursor()
    try:
        cursor2.execute(sql)
        emailaccount.commit()
        cursor2.close()
        return 'removeSucceed'
    except:
        emailaccount.rollback()
        return 'removeDefeat'
def changeToHam(user,title):
    sqlName = changeNameType(user)
    sql = "UPDATE %s SET MailType = '%s' WHERE Title = '%s'" % (sqlName,MailType[2],title)
    emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'emailaccount', charset='utf8')
    cursor2 = emailaccount.cursor()
    try:
        cursor2.execute(sql)
        emailaccount.commit()
        cursor2.close()
        return 'removeSucceed'
    except:
        emailaccount.rollback()
        return 'removeDefeat'

#邮件变已读
def changeReadState(user,sender,readstate,title,date):
    sqlName1 = changeNameType(user)
    sqlName2 = changeNameType(sender)
    sql = "UPDATE %s SET ReadState = '%s' WHERE Title = '%s' and Sender = '%s' and Date = '%s'" % (sqlName1, readstate, title, sqlName2,date)
    emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'emailaccount', charset='utf8')
    cursor2 = emailaccount.cursor()
    try:
        cursor2.execute(sql)
        emailaccount.commit()
        cursor2.close()
        emailaccount.close()
    except:
        emailaccount.rollback()

#def turntoSpamEmail(receiver,title):
    #etitle, edate, etext, esender = searchEmailByTit(receiver, title)
    #if etitle:
       #sql = "DELETE FROM %s WHERE tit = '%s'"%(receiver,title)
       #try:
           #cursor2.execute(sql)
           #emailaccount.commit()
       #except:
           #emailaccount.rollback()
       #sql2 = "INSERT INTO %s VALUES('%s', '%s', '%s', '%s')" % (receiver, etitle, edate, etext, receiver)
       #try:
           #cursor5.execute(sql2)
           #spamEmail1.commit()
       #except:
           #spamEmail1.rollback()


#数据库查询收邮件信息
def searchEmailByTit(receiver,sender,title,date):
    sqlName1 = changeNameType(receiver)
    sqlName2 = changeNameType(sender)
    sql = "SELECT * FROM %s WHERE Title = '%s' and Sender = '%s' and Date = '%s'" % (sqlName1,title,sqlName2,date)
    emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'emailaccount', charset='utf8')
    cursor2 = emailaccount.cursor()
    try:
        # 执行SQL语句
        cursor2.execute(sql)
        # 获取所有记录列表
        results = cursor2.fetchall()
        #print(results)
        for row in results:
            etitle = row[0]
            edate = row[1]
            etext = row[2]
            esender = returnNameType(row[3])
            ereceiver = receiver
            cursor2.close()
            emailaccount.close()
            # 打印结果
            #print("title=%s,date=%s,text=%s,sender=%s,receiver=%s" % (etitle,edate,etext,esender,ereceiver))
            return etitle,edate,etext,esender
    except:
        print("Error: unable to fetch data")

#数据库查询发邮件信息
def searchSendEmailByTit(receiver,sender,title,date):
    sqlName1 = changeNameType(receiver)
    sqlName2 = changeNameType(sender)
    sql = "SELECT * FROM %s WHERE Title = '%s' and Receiver = '%s' and Date = '%s'" % (sqlName2,title,sqlName1,date)
    emailsender = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                  'Shixun1234', 'emailsender', charset='utf8')
    cursor3 = emailsender.cursor()
    try:
        # 执行SQL语句
        cursor3.execute(sql)
        # 获取所有记录列表
        results = cursor3.fetchall()
        #print(results)
        for row in results:
            etitle = row[0]
            edate = row[1]
            etext = row[2]
            ereceiver = returnNameType(row[3])
            cursor3.close()
            emailsender.close()
            # 打印结果
            #print("title=%s,date=%s,text=%s,sender=%s,receiver=%s" % (etitle,edate,etext,esender,ereceiver))
            return etitle,edate,etext,ereceiver
    except:
        print("Error: unable to fetch data")
#删除发送邮件
def deleteSendEmail(receiver,sender,title,date):
    sqlName1 = changeNameType(receiver)
    sqlName2 = changeNameType(sender)
    sql = "DELETE FROM %s WHERE Title = '%s' and Date = '%s' and Receiver = '%s'" % (sqlName2, title, date, sqlName1)
    emailsender = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                  'Shixun1234', 'emailsender', charset='utf8')
    cursor3 = emailsender.cursor()
    try:
        cursor3.execute(sql)
        emailsender.commit()
        cursor3.close()
        emailsender.close()
        updateSendEmailNum(sender, receiver, -1)
    except:
        emailsender.rollback()
#删除接受邮件
def deleteReceiveEmail(receiver,sender,title,date):
    sqlName1 = changeNameType(receiver)
    sqlName2 = changeNameType(sender)
    sql = "DELETE FROM %s WHERE Title = '%s' and Date = '%s' and Sender = '%s'" % (sqlName1, title, date, sqlName2)
    try:
        emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                       'Shixun1234', 'emailaccount', charset='utf8')
        cursor2 = emailaccount.cursor()
        cursor2.execute(sql)
        emailaccount.commit()
        cursor2.close()
        emailaccount.close()
        updateReceiveEmailNum(sender, receiver, -1)
    except:
        emailaccount.rollback()

#数据库删除一封邮件
def deleteEmail(receiver,sender,title,date):
    sqlName1 = changeNameType(receiver)
    sqlName2 = changeNameType(sender)
    etitle, edate, etext, esender = searchEmailByTit(receiver,sender,title,date)
    if etitle:
       sql = "DELETE FROM %s WHERE Title = '%s' and Date = '%s' and Sender = '%s'"%(sqlName1,title,date,sqlName2)
       emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                      'Shixun1234', 'emailaccount', charset='utf8')
       emailsender = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                     'Shixun1234', 'emailsender', charset='utf8')
       cursor3 = emailsender.cursor()
       cursor2 = emailaccount.cursor()
       try:
           cursor2.execute(sql)
           emailaccount.commit()
           cursor2.close()
           emailaccount.close()
       except:
           emailaccount.rollback()
       sql2 = "DELETE FROM %s WHERE Title = '%s' and Date = '%s' and Receiver = '%s'"%(sqlName2,title,date,sqlName1)
       try:
           cursor3.execute(sql2)
           emailsender.commit()
           cursor3.close()
           emailsender.close()
       except:
           emailsender.rollback()
       updateSendEmailNum(sender, receiver, -1)
       updateReceiveEmailNum(sender, receiver, -1)
       return 'deleteSucceed'
    else:
       print("邮件不存在")
       return  'deleteDefeat'

#遍历全部收件箱
def selectAllEmail(user):
    rName, rPass, rContact, rReceive, rSend = searchAccount(user)
    sqlName = changeNameType(user)
    sql = "SELECT * FROM %s" % (sqlName)
    emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'emailaccount', charset='utf8')
    cursor2 = emailaccount.cursor()
    REmailTitList = []
    REmailDateList = []
    REmailTextList = []
    REmailSenderList = []
    RReadStateList = []
    try:
        # 执行SQL语句
        cursor2.execute(sql)
        # 获取所有记录列表
        for i in range(rReceive):
            results = cursor2.fetchone()
            print(results)
            REmailTitList.append(results[0])
            REmailDateList.append(results[1])
            REmailTextList.append(results[2])
            REmailSenderList.append(returnNameType(results[3]))
            RReadStateList.append(results[5])
            print("title=%s,date=%s,text=%s,sender=%s" % \
                (REmailTitList[i], REmailDateList[i], REmailTextList[i], REmailSenderList[i]))
        cursor2.close()
        emailaccount.close()
        return REmailTitList,REmailDateList,REmailTextList,REmailSenderList,rReceive,RReadStateList
    except:
        print("Error: unable to fetch data")

#遍历特定收件箱邮件
def selectTypeEmail(user,type):
    sqlName = changeNameType(user)
    sql = "SELECT * FROM %s WHERE MailType = '%s'" % (sqlName,type)
    emailaccount = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234','emailaccount',charset='utf8')
    cursor2 = emailaccount.cursor()
    REmailTitList = []
    REmailDateList = []
    REmailTextList = []
    REmailSenderList = []
    RReadStateList = []
    num = 0
    try:
        # 执行SQL语句
        cursor2.execute(sql)
        # 获取所有记录列表
        results = cursor2.fetchone()
        while results:
            print(results)
            REmailTitList.append(results[0])
            REmailDateList.append(results[1])
            REmailTextList.append(results[2])
            REmailSenderList.append(returnNameType(results[3]))
            RReadStateList.append(results[5])
            num = num + 1
            results = cursor2.fetchone()
        cursor2.close()
        emailaccount.close()
        return REmailTitList,REmailDateList,REmailTextList,REmailSenderList,num,RReadStateList
    except:
        print("Error: unable to fetch data")

#遍历已发送邮件
def allSendEmail(sender):
    sqlName = changeNameType(sender)
    sql = "SELECT * FROM %s " % (sqlName)
    emailsender = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                  'Shixun1234', 'emailsender', charset='utf8')
    cursor3 = emailsender.cursor()
    SEmailTitList = []
    SEmailDateList = []
    SEmailTextList = []
    SEmailReceiverList = []
    sSend = 0
    try:
        # 执行SQL语句
        cursor3.execute(sql)
        # 获取所有记录列表
        results = cursor3.fetchone()
        while results:
            SEmailTitList.append(results[0])
            SEmailDateList.append(results[1])
            SEmailTextList.append(results[2])
            SEmailReceiverList.append(returnNameType(results[3]))
            sSend =sSend+1
            results = cursor3.fetchone()
        cursor3.close()
        emailsender.close()
        return SEmailTitList, SEmailDateList, SEmailTextList, SEmailReceiverList, sSend
    except:
        print("Error: unable to fetch data")

#往下是联系人操作
#添加联系人
def addContact(user,emailname,nickname,type):
    if searchAccountName(user):
       sqlName = changeNameType(user)
       sql = "INSERT INTO %s VALUES('%s', '%s', '%s')" % (sqlName, emailname, nickname, type)
       contact1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                  'Shixun1234', 'contact', charset='utf8')
       cursor4 = contact1.cursor()
       try:
           cursor4.execute(sql)
           contact1.commit()
           cursor4.close()
           contact1.close()
       except:
           contact1.rollback()
       updateContactNum(user,1)
       result = 'succeed'
    else:
        print("用户不存在")
        result = 'defeat'
    return result
#更新联系人昵称
def updateNickname(user,emailname,nickname):
    sqlName = changeNameType(user)
    sql = "UPDATE %s SET Nickname = '%s' WHERE EmailName = '%s'" % (sqlName,nickname,emailname)
    contact1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234',
                               'contact', charset='utf8')
    cursor4 = contact1.cursor()
    try:
        cursor4.execute(sql)
        contact1.commit()
        cursor4.close()
        contact1.close()
    except:
        contact1.rollback()

#更改联系人分组
def ChangeContactType(user,emailname,type):
    sqlName = changeNameType(user)
    sql = "UPDATE %s SET Type = '%s' WHERE EmailName = '%s'" % (sqlName,type,emailname)
    contact1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234',
                               'contact', charset='utf8')
    cursor4 = contact1.cursor()
    try:
        cursor4.execute(sql)
        contact1.commit()
        cursor4.close()
        contact1.close()
        result = 'succeed'
        return result
    except:
        contact1.rollback()
        result = 'defeat'
        return result

#查看联系人分组
def searchContactType(user):
    sqlName = changeNameType(user)
    sql = "SELECT DISTINCT Type FROM %s" % (sqlName)
    contact1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234',
                               'contact', charset='utf8')
    cursor4 = contact1.cursor()
    typelist = []
    num = 0
    try:
        # 执行SQL语句
        cursor4.execute(sql)
        # 获取所有记录列表
        results = cursor4.fetchone()
        while results:
            print(results)
            typelist.append(results[0])
            num = num + 1
            results = cursor4.fetchone()
        cursor4.close()
        contact1.close()
    except:
        print("Error: unable to fetch data")
    return typelist,num

#查询联系人信息
def searchContact(user ,Emailname):
    sqlName = changeNameType(user)
    sql = "SELECT * FROM %s WHERE EmailName = '%s'"%(sqlName, Emailname)
    contact1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234',
                               'contact', charset='utf8')
    cursor4 = contact1.cursor()
    try:
        # 执行SQL语句
        cursor4.execute(sql)
        # 获取所有记录列表
        results = cursor4.fetchall()
        if results:
            for row in results:
               type = row[2]
               #print(type)
               cursor4.close()
               contact1.close()
               return type
        else:
            return 'defeat'
    except:
        print("Error: unable to fetch data")

#更新联系人的数量
def updateContactNum(user,num):
    uName,uPass,uContact,uReceive,uSend = searchAccount(user)
    if uName:
        sql = "UPDATE ACCOUNT SET ContactNum = %s WHERE EmailName = '%s'" % \
              (uContact+num,uName)
        account1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'email', charset='utf8')
        cursor = account1.cursor()
        try:
            # 执行SQL语句
            cursor.execute(sql)
            # 提交到数据库执行
            account1.commit()
            cursor.close()
            account1.close()
        except:
            # 发生错误时回滚
            account1.rollback()
    else:
        print("账户不存在")

#删除联系人
def deleteContact(user,emailname):
    if searchAccountName(emailname):
        sqlName = changeNameType(user)
        sql = "delete from %s WHERE EmailName = '%s'" % (sqlName,emailname)
        contact1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver',
                                   'Shixun1234', 'contact', charset='utf8')
        cursor4 = contact1.cursor()
        try:
           cursor4.execute(sql)
           contact1.commit()
           cursor4.close()
           contact1.close()
           return 'succeed'
        except:
           contact1.rollback()
        updateContactNum(user,-1)
    else:
        print("联系人不存在")
        return 'defeat'

#遍历某一分组联系人
def SearchTypeContact(user, type):
    sqlName = changeNameType(user)
    sql = "SELECT * FROM %s WHERE Type = '%s'" % (sqlName,type)
    contact1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234',
                               'contact', charset='utf8')
    cursor4 = contact1.cursor()
    EmailNameList = []
    EmailNickNameList = []
    num = 0
    try:
        # 执行SQL语句
        cursor4.execute(sql)
        results = cursor4.fetchone()
        # 获取所有记录列表
        while results:
            EmailNameList.append(results[0])
            EmailNickNameList.append(results[1])
            num = num + 1
            results = cursor4.fetchone()
        cursor4.close()
        contact1.close()
        return EmailNameList, EmailNickNameList, num
    except:
        print("Error: unable to fetch data")

#遍历全部联系人
def SearchallContact(user):
    sqlName = changeNameType(user)
    sql = "SELECT * FROM %s WHERE Type != 'black'" % (sqlName)
    contact1 = pymysql.connect('email-receiver.mysql.database.chinacloudapi.cn', 'manager@email-receiver', 'Shixun1234',
                               'contact', charset='utf8')
    cursor4 = contact1.cursor()
    EmailNameList = []
    EmailNickNameList = []
    TypeList = []
    num = 0
    try:
        # 执行SQL语句
        cursor4.execute(sql)
        results = cursor4.fetchone()
        # 获取所有记录列表
        while results:
            EmailNameList.append(results[0])
            EmailNickNameList.append(results[1])
            TypeList.append(results[2])
            num = num + 1
            results = cursor4.fetchone()
        cursor4.close()
        contact1.close()
        return EmailNameList, EmailNickNameList, TypeList, num
    except:
        print("Error: unable to fetch data")
