import socket
import base64
import hashlib
import re
import struct
from multiprocessing.pool import ThreadPool
import test
import time
import threading

HOST = "0.0.0.0"
PORT = 12000
print('listen at port :', PORT)
MAGIC_STRING = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
HANDSHAKE_STRING = "HTTP/1.1 101 Switching Protocols\r\n" \
                   "Upgrade:websocket\r\n" \
                   "Connection: Upgrade\r\n" \
                   "Sec-WebSocket-Accept: {1}\r\n" \
                   "WebSocket-Location: ws://{2}/chat\r\n" \
                   "WebSocket-Protocol:chat\r\n\r\n"

def recv_data(clientSocket):
    try:
        info = clientSocket.recv(2048)
        if not info:
            return
    except:
        return
    else:
        print(info)
        code_len = info[1] & 0x7f
        if code_len == 0x7e:
            extend_payload_len = info[2:4]
            mask = info[4:8]
            decoded = info[8:]
        elif code_len == 0x7f:
            extend_payload_len = info[2:10]
            mask = info[10:14]
            decoded = info[14:]
        else:
            extend_payload_len = None
            mask = info[2:6]
            decoded = info[6:]
        bytes_list = bytearray()
        print(mask)
        print(decoded)
        for i in range(len(decoded)):
            chunk = decoded[i] ^ mask[i % 4]
            bytes_list.append(chunk)
        raw_str = str(bytes_list, encoding="utf-8")
        print(raw_str)
        return raw_str


def send_data(clientSocket, data):
    token = b'\x81'
    length = len(data.encode())
    if length <= 125:
        token += struct.pack('B', length)
    elif length <= 0xFFFF:
        token += struct.pack('!BH', 126, length)
    else:
        token += struct.pack('!BQ', 127, length)
    data = token + data.encode()
    print(data)
    clientSocket.send(data)


def handshake(serverSocket):
    # print("getting connection")
    clientSocket, addressInfo = serverSocket.accept()
    # print("get connected")
    request = clientSocket.recv(2048)
    # 获取Sec-WebSocket-Key
    ret = re.search(r"Sec-WebSocket-Key: (.*==)", str(request.decode("utf8","ignore")))
    if ret:
        key = ret.group(1)
    else:
        return
    Sec_WebSocket_Key = key + MAGIC_STRING
    # print("key ", Sec_WebSocket_Key)
    # 将Sec-WebSocket-Key先进行sha1加密,转成二进制后在使用base64加密
    response_key = base64.b64encode(hashlib.sha1(bytes(Sec_WebSocket_Key, encoding="utf8")).digest())
    response_key_str = str(response_key)
    response_key_str = response_key_str[2:30]
    # print(response_key_str)
    # 构建websocket返回数据
    response = HANDSHAKE_STRING.replace("{1}", response_key_str).replace("{2}", HOST + ":" + str(PORT))
    clientSocket.send(response.encode())
    return clientSocket

def server(clientSocket):
    while True:
        data = recv_data(clientSocket)
        list = data.split(',')
        first = list[0]+',!'
        list2 = data.replace(first,'')
        operation = str(list[0])
        # 注册操作
        if (operation.strip() == "register"):
            result = test.register(list[1], list[2])
            if (result.strip() == "succeed"):
                print("注册成功")
                send = result.strip()
            else:
                print("注册失败")
                send = "defeat"
            send_data(clientSocket,send)  # 再编码发送
        #登录操作
        elif (operation.strip() == "login"):
            result = test.login(list[1], list[2])
            if (result.strip() == "succeed"):
                print("登录成功")
                send = result.strip()
                test.detectSpam(list[1])
            elif(result.strip() == "noAccount"):
                print("用户名不存在")
                send = result.strip()
            else:
                print("密码错误")
                send = result.strip()
            send_data(clientSocket,send)  # 再编码发送
        #修改密码
        elif (operation.strip() == "updatepassword"):
            result = test.updateAccountPassword(list[1], list[2], list[3])
            if (result.strip() == "succeed"):
                print("修改成功")
                send = result.strip()
            else:
                print("修改失败")
                send = "defeat"
            send_data(clientSocket,send)  # 再编码发送
        #查看收件箱
        elif (operation.strip() == "InBox"):
            REmailTitList, REmailDateList, REmailTextList, REmailSenderList, num, RReadStateList = test.selectTypeEmail(list[1],'ham')
            test.detectSpam(list[1])
            for i in range(num):
                result = "Email"+"," + RReadStateList[i] + ',' + REmailSenderList[i] + ',' + REmailTitList[i] + ',' + REmailDateList[i]
                send = result.strip()
                send_data(clientSocket,send)  # 再编码发送
        #查看发件箱
        elif (operation.strip() == "InSendBox"):
            SEmailTitList, SEmailDateList, SEmailTextList, SEmailReceiverList, sSend = test.allSendEmail(list[1])
            for i in range(sSend):
                result = "Email"+ "," + SEmailReceiverList[i] + ',' + SEmailTitList[i] + ',' + SEmailDateList[i]
                send = result.strip()
                send_data(clientSocket,send)  # 再编码发送
        #查看垃圾箱
        elif (operation.strip() == "InBin"):
            REmailTitList, REmailDateList, REmailTextList, REmailSenderList, num, RReadStateList = test.selectTypeEmail(list[1],'spam')
            test.detectSpam(list[1])
            for i in range(num):
                result = "Email"+',' + RReadStateList[i] + ',' + REmailSenderList[i] + ',' + REmailTitList[i] + ',' + REmailDateList[i]
                send = result.strip()
                send_data(clientSocket,send)  # 再编码发送
        #查看待处理邮件
        elif (operation.strip() == "InWaitingBox"):
            REmailTitList, REmailDateList, REmailTextList, REmailSenderList, num, RReadStateList = test.selectTypeEmail(list[1],'pending')
            test.detectSpam(list[1])
            for i in range(num):
                result = "Email"+',' + RReadStateList[i] + ',' + REmailSenderList[i] + ',' + REmailTitList[i] + ',' + REmailDateList[i]
                send = result.strip()
                send_data(clientSocket,send)  # 再编码发送
        #移动邮件到垃圾箱
        elif (operation.strip() == "removetoBin"):
            result = test.changeToSpam1(list[4],list[1],list[2],list[3])
            send = result.strip()
            send_data(clientSocket, send)  # 再编码发送
        #移动邮件到收件箱
        elif (operation.strip() == "removetoBox"):
            result = test.changeToHam1(list[4],list[1], list[2],list[3])
            send = result.strip()
            send_data(clientSocket, send)  # 再编码发送
        #变邮件为已读
        elif(operation.strip() == "changetoread"):
            test.changeReadState(list[4],list[1],'1',list[2],list[3])
            send = 'succeed'
            send_data(clientSocket, send)  # 再编码发送
        # 变邮件为未读
        elif (operation.strip() == "changetounread"):
            test.changeReadState(list[4], list[1], '0', list[2], list[3])
            send = 'succeed'
            send_data(clientSocket, send)  # 再编码发送
        #删除收件箱邮件
        elif (operation.strip() == "deleteEmail"):
            result = test.deleteReceiveEmail(list[4],list[1],list[2],list[3])
            send = result.strip()
            send_data(clientSocket, send)  # 再编码发送
        #删除发件箱邮件
        elif (operation.strip() == "deleteSendEmail"):
            result = test.deleteSendEmail(list[1],list[4],list[2],list[3])
            send = result.strip()
            send_data(clientSocket, send)  # 再编码发送
        #查看收件箱邮件内容
        elif (operation.strip() == "viewEmail"):
            etitle,edate,etext,esender = test.searchEmailByTit(list[4],list[1],list[2],list[3])
            result = 'viewEmail' + ',' + esender + ',' + etitle + ',' + edate + ',' +etext
            send = result.strip()
            send_data(clientSocket, send)  # 再编码发送
        #查看发件箱邮件内容
        elif (operation.strip() == "viewSendEmail"):
            etitle,edate,etext,ereceiver = test.searchSendEmailByTit(list[1],list[4],list[2],list[3])
            result = 'viewEmail' + ',' + ereceiver + ',' + etitle + ',' + edate + ',' +etext
            send = result.strip()
            send_data(clientSocket, send)  # 再编码发送
        #添加新联系人
        elif (operation.strip() == "addNewLinkman"):
             result = test.addContact(list[4],list[1],list[2],list[3])
             send = result.strip()
             send_data(clientSocket, send)  # 再编码发送
        #删除联系人
        elif (operation.strip() == "delete"):
             result = test.deleteContact(list[2],list[1])
             send = result.strip()
             send_data(clientSocket, send)  # 再编码发送
        #查看某分组联系人
        elif (operation.strip() == "typeContact"):
            EmailNameList, EmailNickNameList, num = test.SearchTypeContact(list[2],list[1])
            for i in range(num):
                result = 'Contact' + ',' + EmailNameList[i] + "," + EmailNickNameList[i]
                send = result.strip()
                send_data(clientSocket, send)  # 再编码发送
        #查看有多少分组
        elif (operation.strip() == "allGrouping"):
            typelist,num = test.searchContactType(list[1])
            result = 'allGrouping' + ','
            for i in range(num):
                result = result + typelist[i] + ','
            send = result.strip()
            send_data(clientSocket, send)  # 再编码发送
        #查看所有联系人
        elif (operation.strip() == "allContact"):
            EmailNameList, EmailNickNameList, TypeList, num = test.SearchallContact(list[1])
            for i in range(num):
                result = 'Contact' + ',' + EmailNameList[i] + ',' + EmailNickNameList[i]
                send = result.strip()
                send_data(clientSocket, send)  # 再编码发送
        #查看所有联系人
        elif (operation.strip() == "allLinkman"):
            EmailNameList, EmailNickNameList, TypeList, num = test.SearchallContact(list[1])
            for i in range(num):
                result = 'allLinkman' + ',' + EmailNameList[i] + "," + EmailNickNameList[i] + ',' + TypeList[i]
                send = result.strip()
                send_data(clientSocket, send)  # 再编码发送
        #发送新邮件
        elif (operation.strip() == "newEmail"):
            date = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time.time()))
            newlist = list2.split(',!')
            result = test.newEmail(newlist[0],newlist[1],date,newlist[2],newlist[3])
            if (result.strip() == "succeed"):
                print("发送成功")
                send = result.strip()
            else:
                print("发送失败")
                send = "defeat"
            send_data(clientSocket,send)  # 再编码发送
        #拉黑联系人
        elif (operation.strip() == "reject"):
            result = test.addContact(list[2],list[1],'','black')
            send = result.strip()
            send_data(clientSocket, send)  # 再编码发送
        #关闭连接
        elif (operation.strip() == "CLOSE"):
            clientSocket.close()
            print('closed')
        #t2 = threading.Thread(target=send_data, args=(clientSocket,))
        #t2.start()


def main():
    # 创建基于tcp的服务器
    serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serverSocket.setsockopt(    socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    host = (HOST, PORT)
    serverSocket.bind(host)
    serverSocket.listen(128)
    print("服务器运行, 等待用户链接")
    # 调用监听
    #handshake(serverSocket)
    pool = ThreadPool(5)
    while True:
        conn = handshake(serverSocket)
        pool.apply_async(server, args=(conn,))
if __name__ == "__main__":
    main()